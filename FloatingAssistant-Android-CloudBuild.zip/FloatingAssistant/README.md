# Floating Assistant (Android)

Proyek Android Studio sederhana untuk panel produktivitas melayang. Panel memiliki gelembung yang bisa digeser, panel kontrol, serta tombol mulai/berhenti. Panel selalu terlihat secara normal dan membutuhkan izin Android **Tampil di atas aplikasi lain**.

## Cara membuka dan membuat APK
1. Instal Android Studio di komputer.
2. Pilih **Open** lalu pilih folder `FloatingAssistant` hasil ekstrak ZIP.
3. Tunggu Gradle Sync selesai. Jika diminta, gunakan Android Gradle Plugin 8.7.3 dan JDK 17.
4. Hubungkan HP Android dengan USB debugging aktif atau gunakan emulator.
5. Tekan **Run** untuk memasang aplikasi. Untuk APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Di HP, buka aplikasi, tekan izin overlay, aktifkan **Tampil di atas aplikasi lain**, kembali ke aplikasi, lalu tekan mulai.

## Batasan
- Ini proyek sumber Android, bukan APK siap instal.
- Membutuhkan Android 8.0 (API 26) atau lebih baru.
- iPhone tidak mengizinkan aplikasi pihak ketiga menampilkan jendela sistem-melayang di atas aplikasi lain seperti Android.
- Tombol MULAI/BERHENTI mengubah status panel demo; belum terhubung ke model AI atau internet.
- Gunakan panel untuk produktivitas. Aplikasi tidak menyembunyikan panel atau melewati pengamanan aplikasi lain.
