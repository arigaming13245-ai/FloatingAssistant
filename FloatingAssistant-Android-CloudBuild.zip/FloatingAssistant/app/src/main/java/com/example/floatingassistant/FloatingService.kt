package com.example.floatingassistant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var running = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 22) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }
    private fun params(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity; x = dp(18); y = dp(180) }
    private fun showBubble() {
        val b = TextView(this).apply {
            text = "AI"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = bg(Color.rgb(15, 100, 210), 40); elevation = dp(8).toFloat()
        }
        bubbleParams = params(dp(58), dp(58))
        b.setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>10) moved=true; bubbleParams.x=ox+dx; bubbleParams.y=oy+dy; wm.updateViewLayout(b,bubbleParams); return true }
                    MotionEvent.ACTION_UP -> { if (!moved) { if (panel == null) showPanel() else hidePanel() }; return true }
                }; return false
            }
        })
        bubble = b; wm.addView(b, bubbleParams)
    }
    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); background = bg(Color.rgb(13,22,43),24); elevation=dp(12).toFloat()
        }
        box.addView(TextView(this).apply { text="FLOATING ASSISTANT"; textSize=17f; setTextColor(Color.rgb(96,190,255)) })
        val status = TextView(this).apply { text="Status: berhenti"; textSize=13f; setTextColor(Color.WHITE); setPadding(0,dp(10),0,dp(10)) }
        box.addView(status)
        val toggle = Button(this).apply { text="MULAI" }
        toggle.setOnClickListener { running = !running; status.text = if (running) "Status: aktif" else "Status: berhenti"; toggle.text = if (running) "BERHENTI" else "MULAI" }
        box.addView(toggle)
        box.addView(TextView(this).apply { text="Panel ini untuk akses cepat dan produktivitas."; textSize=12f; setTextColor(Color.LTGRAY); setPadding(0,dp(8),0,dp(8)) })
        box.addView(Button(this).apply { text="TUTUP PANEL"; setOnClickListener { hidePanel() } })
        panelParams = params(dp(270), WindowManager.LayoutParams.WRAP_CONTENT).apply { x = dp(84); y = dp(180) }
        panel = box; wm.addView(box, panelParams)
    }
    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }
    override fun onDestroy() { hidePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
