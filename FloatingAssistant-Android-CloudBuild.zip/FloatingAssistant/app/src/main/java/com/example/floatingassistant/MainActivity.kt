package com.example.floatingassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(28)); setBackgroundColor(Color.rgb(9,15,31))
        }
        root.addView(TextView(this).apply {
            text = "FLOATING AI\nASSISTANT"; textSize = 27f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Panel produktivitas melayang untuk akses cepat."; textSize = 14f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(24))
        })
        val permission = Button(this).apply { text = "1. IZINKAN TAMPIL DI ATAS APLIKASI" }
        val start = Button(this).apply { text = "2. MULAI FLOATING PANEL" }
        val stop = Button(this).apply { text = "HENTIKAN PANEL" }
        root.addView(permission); root.addView(start); root.addView(stop)
        permission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, FloatingService::class.java))
            else permission.performClick()
        }
        stop.setOnClickListener { stopService(Intent(this, FloatingService::class.java)) }
        setContentView(root)
    }
}
